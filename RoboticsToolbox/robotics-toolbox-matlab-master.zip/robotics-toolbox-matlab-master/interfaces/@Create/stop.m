function stop(robot)

    robot.mode('off');
