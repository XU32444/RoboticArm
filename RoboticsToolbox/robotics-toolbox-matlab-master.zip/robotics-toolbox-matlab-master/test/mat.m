function x = mat(y)
    x = y;
