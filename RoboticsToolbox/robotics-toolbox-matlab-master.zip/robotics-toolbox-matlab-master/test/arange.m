function r = arange(start, stop, step)
    r = [start:step:stop]';
