To run tests in matlab.
  

  Make the folder containing all the test you working folder 
  
  Type >> runtests

Make sure to add the old unit-test stuff

